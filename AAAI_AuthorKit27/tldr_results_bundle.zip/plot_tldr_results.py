from pathlib import Path
import argparse

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator


DATASETS = ["AISHELL1-NE", "ContextASR-ZH", "ContextASR-EN", "AISpeech-Meeting"]
MODELS = ["GLCLAP", "CLAR", "TLDR"]


def configure_matplotlib():
    """Configure dimensions and typography without fixing a journal-specific font."""
    plt.rcParams.update({
        "font.size": 9,
        "axes.labelsize": 9,
        "axes.titlesize": 10,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "legend.fontsize": 8,
        "figure.dpi": 150,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "axes.spines.top": False,
        "axes.spines.right": False,
    })


def load_results(excel_path: Path) -> pd.DataFrame:
    df = pd.read_excel(excel_path, sheet_name="Results_Long")
    required = {
        "Training Regime", "Model", "Dataset",
        "F1", "Precision", "Recall", "R@1", "R@5", "R@10"
    }
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    return df


def save_pdf(fig, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, format="pdf")
    plt.close(fig)


def grouped_f1_bar(df: pd.DataFrame, training: str, output: Path):
    subset = df[df["Training Regime"] == training].copy()
    pivot = subset.pivot(index="Dataset", columns="Model", values="F1").reindex(DATASETS)
    pivot = pivot[MODELS]

    x = np.arange(len(DATASETS))
    width = 0.24

    fig, ax = plt.subplots(figsize=(7.0, 3.25))
    for index, model in enumerate(MODELS):
        offset = (index - 1) * width
        bars = ax.bar(x + offset, pivot[model].to_numpy(), width, label=model)
        ax.bar_label(bars, fmt="%.1f", padding=2, fontsize=7)

    ax.set_ylabel("F1 (%)")
    ax.set_title(f"Hotword detection under {training} training", pad=30)
    ax.set_xticks(x, DATASETS)
    ax.set_ylim(0, 108)
    ax.yaxis.set_major_locator(MultipleLocator(20))
    ax.grid(axis="y", linewidth=0.5, alpha=0.35)
    ax.legend(
        ncol=3,
        frameon=False,
        loc="lower center",
        bbox_to_anchor=(0.5, 1.035),
        columnspacing=1.4,
    )
    fig.tight_layout()
    save_pdf(fig, output)


def tldr_gain_bar(df: pd.DataFrame, output: Path):
    rows = []
    for training in ["ZH+EN", "ZH only"]:
        for dataset in DATASETS:
            subset = df[
                (df["Training Regime"] == training) &
                (df["Dataset"] == dataset)
            ]
            tldr = float(subset.loc[subset["Model"] == "TLDR", "F1"].iloc[0])
            baseline = float(
                subset.loc[subset["Model"].isin(["GLCLAP", "CLAR"]), "F1"].max()
            )
            rows.append((training, dataset, tldr - baseline))

    gain = pd.DataFrame(rows, columns=["Training", "Dataset", "Gain"])
    x = np.arange(len(DATASETS))
    width = 0.36

    fig, ax = plt.subplots(figsize=(7.0, 3.0))
    for index, training in enumerate(["ZH+EN", "ZH only"]):
        vals = gain[gain["Training"] == training].set_index("Dataset").reindex(DATASETS)
        offset = (index - 0.5) * width
        bars = ax.bar(x + offset, vals["Gain"].to_numpy(), width, label=training)
        ax.bar_label(bars, fmt="%+.1f", padding=2, fontsize=7)

    ax.axhline(0, linewidth=0.8)
    ax.set_ylabel("Absolute F1 gain (points)")
    ax.set_title("TLDR gain over the strongest baseline")
    ax.set_xticks(x, DATASETS)
    ax.grid(axis="y", linewidth=0.5, alpha=0.35)
    ax.legend(frameon=False)
    fig.tight_layout()
    save_pdf(fig, output)


def training_degradation(df: pd.DataFrame, dataset: str, output: Path):
    subset = df[df["Dataset"] == dataset].copy()
    x_labels = ["ZH+EN", "ZH only"]
    x = np.arange(len(x_labels))
    left_label_offsets = {
        "GLCLAP": (-8, -10),
        "CLAR": (0, 8),
        "TLDR": (8, 16),
    }
    right_label_offsets = {
        "GLCLAP": (7, -8),
        "CLAR": (7, 8),
        "TLDR": (7, 0),
    }

    fig, ax = plt.subplots(figsize=(4.5, 3.2))
    for model in MODELS:
        values = []
        for training in x_labels:
            value = subset[
                (subset["Training Regime"] == training) &
                (subset["Model"] == model)
            ]["F1"].iloc[0]
            values.append(float(value))

        ax.plot(x, values, marker="o", linewidth=1.6)
        left_dx, left_dy = left_label_offsets[model]
        ax.annotate(
            f"{values[0]:.1f}",
            (x[0], values[0]),
            xytext=(left_dx, left_dy),
            textcoords="offset points",
            ha="center",
            fontsize=7,
        )
        right_dx, right_dy = right_label_offsets[model]
        ax.annotate(
            f"{model}  {values[1]:.1f}",
            (x[1], values[1]),
            xytext=(right_dx, right_dy),
            textcoords="offset points",
            va="center",
            fontsize=7,
        )

    ax.set_xticks(x, x_labels)
    ax.set_ylabel("F1 (%)")
    ax.set_title(f"Robustness to restricted training: {dataset}")
    ax.set_xlim(-0.12, 1.35)
    ax.set_ylim(0, 105)
    ax.grid(axis="y", linewidth=0.5, alpha=0.35)
    fig.tight_layout()
    save_pdf(fig, output)


def ranking_curve_zh_only_english(df: pd.DataFrame, output: Path):
    subset = df[
        (df["Training Regime"] == "ZH only") &
        (df["Dataset"] == "ContextASR-EN")
    ].set_index("Model")

    ks = np.array([1, 5, 10])
    fig, ax = plt.subplots(figsize=(4.4, 3.2))
    rank_offsets = {
        "GLCLAP": (-7, -10),
        "CLAR": (7, 5),
        "TLDR": (0, 5),
    }
    for model in MODELS:
        values = subset.loc[model, ["R@1", "R@5", "R@10"]].to_numpy(dtype=float)
        ax.plot(ks, values, marker="o", linewidth=1.6, label=model)
        for point_index, (k, value) in enumerate(zip(ks, values)):
            if point_index == 0:
                dx, dy = rank_offsets[model]
            else:
                dx, dy = 0, 5
            ax.annotate(
                f"{value:.1f}",
                (k, value),
                xytext=(dx, dy),
                textcoords="offset points",
                ha="center",
                fontsize=7,
            )

    ax.set_xlabel("K")
    ax.set_ylabel("Recall@K (%)")
    ax.set_title("Zero-shot English ranking under Chinese-only training")
    ax.set_xticks(ks)
    ax.set_xlim(0.45, 10.45)
    ax.set_ylim(0, 60)
    ax.grid(axis="y", linewidth=0.5, alpha=0.35)
    ax.legend(frameon=False)
    fig.tight_layout()
    save_pdf(fig, output)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--excel",
        type=Path,
        default=Path(__file__).with_name("tldr_experiment_results.xlsx"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).with_name("figures"),
    )
    args = parser.parse_args()

    configure_matplotlib()
    df = load_results(args.excel)

    grouped_f1_bar(df, "ZH+EN", args.output_dir / "fig_f1_zh_en.pdf")
    grouped_f1_bar(df, "ZH only", args.output_dir / "fig_f1_zh_only.pdf")
    tldr_gain_bar(df, args.output_dir / "fig_tldr_f1_gain.pdf")
    training_degradation(
        df, "ContextASR-ZH",
        args.output_dir / "fig_training_degradation_contextasr_zh.pdf",
    )
    training_degradation(
        df, "AISpeech-Meeting",
        args.output_dir / "fig_training_degradation_meeting.pdf",
    )
    ranking_curve_zh_only_english(
        df,
        args.output_dir / "fig_zh_only_contextasr_en_ranking.pdf",
    )

    print(f"Saved figures to: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
